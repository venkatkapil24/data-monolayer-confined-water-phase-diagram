AIMD simulations are performed with cp2k version 8.1.
The input files include the standard cp2k input and the initial geometry